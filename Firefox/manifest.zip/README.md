* Verlanglijst.online Rekenmachine
Geeft de totaal som voor alle producten in je lijstje op https://verlanglijst.online/
 
 *Om te installeren:
 Firefox (incl. DuckDuckGo): Installeer via de add-on store, 
 of ga naar about:addons , druk op het tandwieletje and install Add-on from file, kies daar het .zip bestand.