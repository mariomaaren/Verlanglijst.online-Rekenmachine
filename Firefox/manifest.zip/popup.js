document.addEventListener('DOMContentLoaded', () => {
  const positionEl = document.getElementById('position');
  const darkModeEl = document.getElementById('darkMode');

  // Load current settings
  chrome.storage.sync.get(['position', 'dark'], data => {
    positionEl.value = data.position || 'bottom-right-fixed';
    darkModeEl.value = String(data.dark);
  });

  // Save position
  positionEl.addEventListener('change', () => {
    chrome.storage.sync.set({ position: positionEl.value });
  });

  // Save dark/light setting
  darkModeEl.addEventListener('change', () => {
    chrome.storage.sync.set({ dark: darkModeEl.value === 'true' });
  });
});
